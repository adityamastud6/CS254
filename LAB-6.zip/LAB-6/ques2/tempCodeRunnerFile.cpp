 // for(int x : topological_sort) {
    //     for(int child : adj[x]) {
    //         path[child] = max(path[child], 1 + path[x]);
    //         max_path = max(max_path, path[child]);
    //     }
    // }
    